from django.contrib import admin
from django.urls import path, include  # include 用来引入 app 的 urls

urlpatterns = [
    path('admin/', admin.site.urls),       # 管理后台
    path('', include('myapp.urls')),       # 引入 myapp 应用的路由
]
