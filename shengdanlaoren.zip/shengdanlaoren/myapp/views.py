from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_http_methods
import paramiko
import json
from functools import wraps

# 多个 SSH 终端配置
SSH_CONFIG = {
    "quyuan": {
        "host": "8.159.132.117",
        "port": 5050,
        "user": "pc",
        "pass": "123"
    },
    # "kongzi": {
    #     "host": "8.159.132.117",
    #     "port": 7956,
    #     "user": "pc",
    #     "pass": "123"   
    # },
    # "wuke": {
    #     "host": "8.159.132.117",
    #     "port": 8264,
    #     "user": "pc",
    #     "pass": "123"   
    # },
    # "lishimin": {
    #     "host": "8.159.132.117",
    #     "port": 9265,
    #     "user": "pc",
    #     "pass": "123"   
    # },
    # "aliyun-test": {
    #     "host": "8.159.132.117",
    #     "port": 22,
    #     "user": "root",
    #     "pass": "Wdmzjzfm520."   
    # },
    # "bohu": {
    #     "host": "8.159.132.117",
    #     "port": 9265,
    #     "user": "pc",
    #     "pass": "123"   
    # }
}

REMOTE_PATH = "~/ws_ros/src/realtime_conversation/src/tts"

# 装饰器：处理SSH操作的通用装饰器
def ssh_operation(func):
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        if request.method != "POST":
            return JsonResponse({"status": "invalid request"})
        
        try:
            data = json.loads(request.body)
            target = data.get("ssh_target", "kongzi")
            
            # 调用原函数，传入SSH连接和解析后的数据
            result = func(request, data, target, *args, **kwargs)
            return result
        except json.JSONDecodeError:
            return JsonResponse({"status": "error", "message": "无效的JSON数据"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return wrapper

def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'欢迎回来，{username}！')
            return redirect('index')
        else:
            messages.error(request, '用户名或密码错误，请重试。')
    
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    messages.success(request, '您已成功登出。')
    return redirect('login')

def ssh_connect(target="kongzi"):
    cfg = SSH_CONFIG.get(target)
    if not cfg:
        raise ValueError("未找到对应 SSH 配置")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=cfg["host"], port=cfg["port"], username=cfg["user"], password=cfg["pass"])
    return ssh

@ensure_csrf_cookie
@login_required
def index(request):
    return render(request, "index.html", {"ssh_targets": SSH_CONFIG.keys()})

@ensure_csrf_cookie
@login_required
def action(request):
    # 排除 wuke 选项，只显示其他三个 SSH 终端
    ssh_targets = [name for name in SSH_CONFIG.keys() if name != "wuke"]
    return render(request, "action.html", {"ssh_targets": ssh_targets})

@ensure_csrf_cookie
@login_required
def face(request):
    # 排除 wuke 选项，只显示其他三个 SSH 终端
    ssh_targets = [name for name in SSH_CONFIG.keys() if name != "wuke"]
    return render(request, "face.html", {"ssh_targets": ssh_targets})

@ensure_csrf_cookie
def csrf_test(request):
    return render(request, "csrf_test.html")

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_command(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;echo 0")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def count_mp3(request, data, target):
    ssh = ssh_connect(target)
    # 获取所有txt文件
    cmd = f'cd {REMOTE_PATH} && ls *.txt 2>/dev/null'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    txt_files = stdout.read().decode().split()
    
    # 获取所有mp3文件
    cmd2 = f'cd {REMOTE_PATH} && ls *.mp3 2>/dev/null'
    stdin2, stdout2, stderr2 = ssh.exec_command(cmd2)
    mp3_files = stdout2.read().decode().split()
    
    files = []
    orphan_txt = []  # 没有对应mp3的txt文件
    
    # 检查每个txt文件是否有对应的mp3
    for txt in txt_files:
        mp3_file = txt.replace(".txt", ".mp3")
        if mp3_file in mp3_files:
            files.append(mp3_file)
        else:
            orphan_txt.append(txt)

    ssh.close()
    return JsonResponse({
        "status": "ok", 
        "count": len(files), 
        "files": files,
        "orphan_txt": orphan_txt
    })

@require_http_methods(["POST"])
@login_required
@ssh_operation
def delete_file(request, data, target):
    filename = data.get("filename")
    if not filename:
        return JsonResponse({"status": "error", "message": "未指定文件名"})

    txt_file = filename.replace(".mp3", ".txt")
    ssh = ssh_connect(target)
    cmd = f'rm -f {REMOTE_PATH}/{filename} {REMOTE_PATH}/{txt_file}'
    ssh.exec_command(cmd)
    ssh.close()
    return JsonResponse({"status": "ok"})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def generate_mp3(request, data, target):
    txt_filename = data.get("txt_filename")
    if not txt_filename:
        return JsonResponse({"status": "error", "message": "未指定txt文件名"})

    ssh = ssh_connect(target)
    cmd = f'cd {REMOTE_PATH} && export DISPLAY=:0;source /opt/ros/noetic/setup.bash; python3 aio.py --tts ./{txt_filename}'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    
    if err:
        return JsonResponse({"status": "error", "message": f"生成失败: {err}"})
    return JsonResponse({"status": "ok", "message": "MP3生成成功"})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def create_txt(request, data, target):
    filename = data.get("filename")
    content = data.get("content")
    
    if not filename:
        return JsonResponse({"status": "error", "message": "未指定文件名"})
    if not content:
        return JsonResponse({"status": "error", "message": "未指定文件内容"})

    ssh = ssh_connect(target)
    # 使用echo命令创建文件
    cmd = f'cd {REMOTE_PATH} && echo "{content}" > "{filename}"'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    err = stderr.read().decode()
    ssh.close()
    
    if err:
        return JsonResponse({"status": "error", "message": f"创建失败: {err}"})
    return JsonResponse({"status": "ok", "message": "文件创建成功"})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_autostart(request, data, target):
    ssh = ssh_connect(target)
    if target in ["kongzi", "quyuan", "lishimin"]:
        command = "export DISPLAY=:0; bash /home/pc/roslaunch_autostart.sh"
    elif target == "wuke":
        command = "export DISPLAY=:0; bash /home/pc/ymbot_e/ymbot_c_start.sh"
    else:
        ssh.close()
        return JsonResponse({"status": "error", "message": "不支持的SSH目标"})

    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})



@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_mute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-mute {} true"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_unmute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-mute {} false"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_reboot(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; sudo reboot"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_stopterminal(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0; pkill gnome-terminal")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def play_music(request, data, target):
    filename = data.get("filename")
    if not filename:
        return JsonResponse({"status": "error", "message": "未指定文件名"})

    ssh = ssh_connect(target)
    # 使用 aio.py 播放指定的 mp3 文件，统一走 tts 目录下的脚本
    cmd = f'cd {REMOTE_PATH} && export DISPLAY=:0;source /opt/ros/noetic/setup.bash; python3 aio.py --mp3 ./{filename}'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    
    if err:
        return JsonResponse({"status": "error", "message": f"播放失败: {err}"})
    return JsonResponse({"status": "ok", "message": f"{filename} 开始播放"})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_poweroff(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; sudo poweroff"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face_tracking(request, data, target):
    # 仅允许孔子、屈原、唐太宗
    allowed_targets = ["quyuan"]
    if target not in allowed_targets:
        return JsonResponse({"status": "error", "message": "该SSH终端不支持视觉追踪功能"})

    ssh = ssh_connect(target)
    command = "export DISPLAY=:0;source /opt/ros/noetic/setup.bash; rostopic pub /enable_face_tracking std_msgs/Bool \"data: true\" --once"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    if err:
        return JsonResponse({"status": "error", "message": f"开启视觉追踪失败: {err}"})
    return JsonResponse({"status": "ok", "message": "视觉追踪已开启", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face_tracking_off(request, data, target):
    # 仅允许孔子、屈原、唐太宗
    allowed_targets = ["quyuan"]
    if target not in allowed_targets:
        return JsonResponse({"status": "error", "message": "该SSH终端不支持视觉追踪功能"})

    ssh = ssh_connect(target)
    command = "export DISPLAY=:0;source /opt/ros/noetic/setup.bash; rostopic pub /enable_face_tracking std_msgs/Bool \"data: false\" --once"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    if err:
        return JsonResponse({"status": "error", "message": f"关闭视觉追踪失败: {err}"})
    return JsonResponse({"status": "ok", "message": "视觉追踪已关闭", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_random_head_on(request, data, target):
    # 仅允许孔子、屈原、唐太宗
    allowed_targets = ["quyuan"]
    if target not in allowed_targets:
        return JsonResponse({"status": "error", "message": "该SSH终端不支持头部随机动作功能"})

    ssh = ssh_connect(target)
    command = "export DISPLAY=:0;source /opt/ros/noetic/setup.bash; rostopic pub /enable_random_head std_msgs/Bool \"data: true\" --once"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    if err:
        return JsonResponse({"status": "error", "message": f"开启头部随机动作失败: {err}"})
    return JsonResponse({"status": "ok", "message": "头部随机动作已开启", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_random_head_off(request, data, target):
    # 仅允许孔子、屈原、唐太宗
    allowed_targets = ["quyuan"]
    if target not in allowed_targets:
        return JsonResponse({"status": "error", "message": "该SSH终端不支持头部随机动作功能"})

    ssh = ssh_connect(target)
    command = "export DISPLAY=:0;source /opt/ros/noetic/setup.bash; rostopic pub /enable_random_head std_msgs/Bool \"data: false\" --once"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    if err:
        return JsonResponse({"status": "error", "message": f"关闭头部随机动作失败: {err}"})
    return JsonResponse({"status": "ok", "message": "头部随机动作已关闭", "stdout": out, "stderr": err})


# 12. 身体麦克风取消静音（按用户提供命令）
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_body_mic_unmute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-mute {} false"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 13. 身体麦克风静音（按用户提供命令）
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_body_mic_mute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-mute {} true"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 14. 身体麦克风音量+10%
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_body_mic_vol_up(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-volume {} +10%"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 15. 身体麦克风音量-10%
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_body_mic_vol_down(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sources | grep \"FY-SP003\" | awk '{print $1}' | xargs -I{} pactl set-source-volume {} -10%"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 16. 音响音量+10%
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_speaker_vol_up(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sinks | awk 'NR==1{print $1}' | xargs -I{} pactl set-sink-volume {} +10%"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 17. 音响音量-10%
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_speaker_vol_down(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sinks | awk 'NR==1{print $1}' | xargs -I{} pactl set-sink-volume {} -10%"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 18. 静音音响
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_speaker_mute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sinks | awk 'NR==1{print $1}' | xargs -I{} pactl set-sink-mute {} true"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 19. 取消静音音响
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_speaker_unmute(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0; pactl list short sinks | awk 'NR==1{print $1}' | xargs -I{} pactl set-sink-mute {} false"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


# 20. 念诗
@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_nianshi(request, data, target):
    ssh = ssh_connect(target)
    command = "export DISPLAY=:0;source /opt/ros/noetic/setup.bash; rostopic pub /introduce std_msgs/Float32 \"data: 2.0\" --once"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})

@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_lip_sync_play(request, data, target):
    txt_filename = data.get("txt_filename")
    if not txt_filename:
        return JsonResponse({"status": "error", "message": "未指定txt文件名"})

    # 根据 txt 文件名推导对应的 mp3 文件名
    mp3_filename = txt_filename.replace(".txt", ".mp3")

    ssh = ssh_connect(target)
    cmd = f'cd {REMOTE_PATH} && export DISPLAY=:0;source /opt/ros/noetic/setup.bash; python3 aio.py --mp3 ./{mp3_filename}'
    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()
    
    if err:
        return JsonResponse({"status": "error", "message": f"对口型播放失败: {err}"})
    return JsonResponse({"status": "ok", "message": f"{txt_filename} 开始对口型播放"})
