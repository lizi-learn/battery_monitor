from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods

# 复用现有的 SSH 工具与装饰器，避免重复代码
from .views import ssh_connect, ssh_operation


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face1(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G1F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#1GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face2(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G2F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#2GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face3(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G3F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#3GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face4(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G4F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#4GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face5(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G5F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#5GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face6(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G6F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#6GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face7(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G7F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#7GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face8(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G8F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#8GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face9(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G9F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#9GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_face10(request, data, target):
    ssh = ssh_connect(target)
    # 根据终端类型选择命令格式
    if target == 'bohu':
        command = "export DISPLAY=:0; echo -ne \"G10F1\\r\\n\" > /dev/ttyACM0"
    else:
        command = "export DISPLAY=:0; echo -ne \"#10GC1\\r\\n\" > /dev/ymbothead"
    stdin, stdout, stderr = ssh.exec_command(command)
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})
