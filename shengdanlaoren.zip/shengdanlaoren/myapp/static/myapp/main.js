// 获取CSRF令牌
function getCSRFToken() {
    // 首先尝试从meta标签获取
    const metaToken = document.querySelector('meta[name="csrf-token"]');
    if (metaToken) {
        return metaToken.getAttribute('content');
    }
    
    // 然后尝试从cookie获取
    const name = 'csrftoken';
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function getSelectedSSH() {
    return document.getElementById("ssh-target").value;
}

// 通用fetch请求函数
function makeRequest(url, data, options = {}) {
    const defaultOptions = {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ ssh_target: getSelectedSSH(), ...data })
    };
    
    return fetch(url, { ...defaultOptions, ...options })
        .then(res => res.json())
        .catch(err => {
            throw new Error(`请求出错: ${err}`);
        });
}

// 通用结果显示函数
function showResult(resultDiv, content, isHTML = false) {
    if (isHTML) {
        resultDiv.innerHTML = content;
    } else {
        resultDiv.textContent = content;
    }
}

// 通用成功/失败处理函数
function handleResponse(data, successMessage, errorPrefix = "操作") {
    if (data.status === "ok") {
        return { success: true, message: successMessage };
    } else {
        return { success: false, message: `${errorPrefix}失败: ${data.message}` };
    }
}

function runScript() {
    if (!confirm('确定要执行该命令吗？')) {
        return;
    }
    const resultDiv = document.getElementById("result");
    showResult(resultDiv, "正在执行，请稍等...");

    makeRequest("/run-command/", {})
        .then(data => {
            if (data.status === "ok") {
                showResult(resultDiv, `标准输出:\n${data.stdout}\n\n标准错误:\n${data.stderr}`);
            } else {
                showResult(resultDiv, "执行出错:\n" + data.message);
            }
        })
        .catch(err => {
            showResult(resultDiv, err.message);
        });
}

function countMp3() {
    const mp3List = document.getElementById("mp3-list");
    mp3List.innerHTML = "<li>正在统计，请稍等...</li>";

    makeRequest("/count-mp3/", {})
        .then(data => {
            if(data.status === "ok"){
                mp3List.innerHTML = "";
                
                // 显示有对应mp3的文件
                if(data.count > 0){
                    data.files.forEach(file => {
                        const li = document.createElement("li");
                        li.textContent = file;

                        const playBtn = document.createElement("button");
                        playBtn.textContent = "播放";
                        playBtn.style.backgroundColor = "#4CAF50";
                        playBtn.style.color = "white";
                        playBtn.style.marginRight = "5px";
                        playBtn.onclick = () => playMusic(file);

                        const delBtn = document.createElement("button");
                        delBtn.textContent = "删除";
                        delBtn.style.backgroundColor = "#f44336";
                        delBtn.style.color = "white";
                        delBtn.onclick = () => deleteFile(file);

                        li.appendChild(playBtn);
                        li.appendChild(delBtn);
                        mp3List.appendChild(li);
                    });
                }
                
                // 显示没有对应mp3的txt文件
                if(data.orphan_txt && data.orphan_txt.length > 0){
                    data.orphan_txt.forEach(txt => {
                        const li = document.createElement("li");
                        li.textContent = `${txt} (无对应MP3)`;

                        const genBtn = document.createElement("button");
                        genBtn.textContent = "生成";
                        genBtn.style.backgroundColor = "#2196F3";
                        genBtn.style.color = "white";
                        genBtn.style.marginRight = "5px";
                        genBtn.onclick = () => generateMp3(txt);

                        li.appendChild(genBtn);
                        mp3List.appendChild(li);
                    });
                }
                
                if(data.count === 0 && (!data.orphan_txt || data.orphan_txt.length === 0)){
                    mp3List.innerHTML = "<li>没有找到任何文件。</li>";
                }
            } else {
                mp3List.innerHTML = `<li>统计出错: ${data.message}</li>`;
            }
        })
        .catch(err => {
            mp3List.innerHTML = `<li>${err.message}</li>`;
        });
}

function deleteFile(filename) {
    if(!confirm(`确定删除 ${filename} 及对应的 txt 文件吗？`)) return;

    makeRequest("/delete-file/", { filename })
        .then(data => {
            const result = handleResponse(data, `${filename} 删除成功`, "删除");
            alert(result.message);
            if (result.success) {
                countMp3(); // 刷新列表
            }
        })
        .catch(err => alert(err.message));
}

function playMusic(filename) {
    if(!confirm(`确定要播放 ${filename} 吗？`)) return;

    makeRequest("/play-music/", { filename })
        .then(data => {
            const result = handleResponse(data, `${filename} 开始播放`, "播放");
            alert(result.message);
        })
        .catch(err => alert(err.message));
}

function generateMp3(txtFilename) {
    if(!confirm(`确定要为 ${txtFilename} 生成MP3文件吗？`)) return;

    makeRequest("/generate-mp3/", { txt_filename: txtFilename })
        .then(data => {
            const result = handleResponse(data, `${txtFilename} MP3生成成功`, "生成");
            alert(result.message);
            if (result.success) {
                countMp3(); // 刷新列表
            }
        })
        .catch(err => alert(err.message));
}

function runLipSyncPlay(txtFilename) {
    if(!confirm(`确定要对口型播放 ${txtFilename} 吗？`)) return;

    makeRequest("/run_lip_sync_play/", { txt_filename: txtFilename })
        .then(data => {
            const result = handleResponse(data, `${txtFilename} 开始对口型播放`, "对口型播放");
            alert(result.message);
        })
        .catch(err => alert(err.message));
}

function createTxtFile() {
    const txtName = document.getElementById("txt-name").value.trim();
    const txtContent = document.getElementById("txt-content").value.trim();
    
    if (!txtName) {
        alert("请输入文件名");
        return;
    }
    
    if (!txtContent) {
        alert("请输入文件内容");
        return;
    }
    
    // 确保文件名不包含.txt后缀
    const filename = txtName.endsWith('.txt') ? txtName : txtName + '.txt';
    
    if (!confirm(`确定要创建文件 ${filename} 吗？`)) return;
    
    makeRequest("/create-txt/", { filename, content: txtContent })
        .then(data => {
            const result = handleResponse(data, `${filename} 创建成功`, "创建");
            alert(result.message);
            if (result.success) {
                // 清空输入框
                document.getElementById("txt-name").value = "";
                document.getElementById("txt-content").value = "";
                // 刷新文件列表
                countMp3();
            }
        })
        .catch(err => alert(err.message));
}

function runAutostart() {
    const target = getSelectedSSH();
    const scriptLabel = target === 'wuke' ? 'ymbot_c_start.sh' : 'roslaunch_autostart.sh';
    
    if (!confirm(`确定要执行 ${scriptLabel} 吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在执行 ${scriptLabel}...`);
    
    makeRequest('/run_autostart/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}



function runstopterminal() {
    if (!confirm('确定要关闭所有窗口吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在关闭窗口...');
    
    makeRequest('/run_stopterminal/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}



function runMute() {
    if (!confirm('确定要静音吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在静音...');
    
    makeRequest('/run_mute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runUnmute() {
    if (!confirm('确定要取消静音吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在取消静音...');
    
    makeRequest('/run_unmute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runBodyMicUnmute() {
    if (!confirm('确定要取消静音身体麦克风吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在取消静音身体麦克风...');
    makeRequest('/run_body_mic_unmute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runBodyMicMute() {
    if (!confirm('确定要静音身体麦克风吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在静音身体麦克风...');
    makeRequest('/run_body_mic_mute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runBodyMicVolUp() {
    if (!confirm('确定要将身体麦克风音量提高10%吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在提高身体麦克风音量(+10%)...');
    makeRequest('/run_body_mic_vol_up/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runBodyMicVolDown() {
    if (!confirm('确定要将身体麦克风音量降低10%吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在降低身体麦克风音量(-10%)...');
    makeRequest('/run_body_mic_vol_down/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runSpeakerVolUp() {
    if (!confirm('确定要将音响音量提高10%吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在提高音响音量(+10%)...');
    makeRequest('/run_speaker_vol_up/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runSpeakerVolDown() {
    if (!confirm('确定要将音响音量降低10%吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在降低音响音量(-10%)...');
    makeRequest('/run_speaker_vol_down/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runSpeakerMute() {
    if (!confirm('确定要静音音响吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在静音音响...');
    makeRequest('/run_speaker_mute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runSpeakerUnmute() {
    if (!confirm('确定要取消静音音响吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在取消静音音响...');
    makeRequest('/run_speaker_unmute/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runNianshi() {
    if (!confirm('确定要念诗吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在念诗...');
    makeRequest('/run_nianshi/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}



function runReboot() {
    if (!confirm('确定要重启吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在重启...');
    
    makeRequest('/run_reboot/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runPoweroff() {
    if (!confirm('确定要关机吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在关机...');
    
    makeRequest('/run_poweroff/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFaceTracking() {
    const target = getSelectedSSH();
    const allowedTargets = ['kongzi', 'quyuan', 'lishimin'];
    
    if (!allowedTargets.includes(target)) {
        alert('视觉追踪功能仅支持孔子、屈原、唐太宗终端');
        return;
    }
    
    if (!confirm('确定要开启视觉追踪吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在开启视觉追踪...');
    
    makeRequest('/run_face_tracking/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <p>${data.message}</p>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFaceTrackingOff() {
    const target = getSelectedSSH();
    const allowedTargets = ['kongzi', 'quyuan', 'lishimin'];
    if (!allowedTargets.includes(target)) {
        alert('视觉追踪功能仅支持孔子、屈原、唐太宗终端');
        return;
    }
    if (!confirm('确定要关闭视觉追踪吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在关闭视觉追踪...');
    makeRequest('/run_face_tracking_off/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <p>${data.message}</p>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runRandomHeadOn() {
    const target = getSelectedSSH();
    const allowedTargets = ['kongzi', 'quyuan', 'lishimin'];
    if (!allowedTargets.includes(target)) {
        alert('头部随机动作仅支持孔子、屈原、唐太宗终端');
        return;
    }
    if (!confirm('确定要开启头部随机动作吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在开启头部随机动作...');
    makeRequest('/run_random_head_on/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <p>${data.message}</p>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runRandomHeadOff() {
    const target = getSelectedSSH();
    const allowedTargets = ['kongzi', 'quyuan', 'lishimin'];
    if (!allowedTargets.includes(target)) {
        alert('头部随机动作仅支持孔子、屈原、唐太宗终端');
        return;
    }
    if (!confirm('确定要关闭头部随机动作吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在关闭头部随机动作...');
    makeRequest('/run_random_head_off/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <p>${data.message}</p>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}



function runDianzan() {
    if (!confirm('确定要点赞吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在点赞...');
    
    makeRequest('/run_dianzan/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runWoshou() {
    if (!confirm('确定要握手吗？')) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在握手...');
    
    makeRequest('/run_woshou/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runXiexie() {
    if (!confirm('确定要谢谢吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在谢谢...');
    makeRequest('/run_xiexie/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runPaizhao() {
    if (!confirm('确定要拍照吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在拍照...');
    makeRequest('/run_paizhao/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}



function runBixin() {
    if (!confirm('确定要比心吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在比心...');
    makeRequest('/run_bixin/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runJujue() {
    if (!confirm('确定要拒绝吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在拒绝...');
    makeRequest('/run_jujue/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runMaimeng() {
    if (!confirm('确定要卖萌吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在卖萌...');
    makeRequest('/run_maimeng/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runBuyao() {
    if (!confirm('确定要不要吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在不要...');
    makeRequest('/run_buyao/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

// 根据所选SSH终端动态更新"自动启动"按钮文案
document.addEventListener('DOMContentLoaded', function() {
    function updateAutostartButtonLabel() {
        const btn = document.getElementById('btn-autostart');
        if (!btn) return;
        const target = getSelectedSSH();
        btn.textContent = target === 'wuke' ? '运行 ymbot_c_start.sh' : '运行 roslaunch_autostart.sh';
    }

    const select = document.getElementById('ssh-target');
    if (select) {
        select.addEventListener('change', updateAutostartButtonLabel);
    }
    updateAutostartButtonLabel();
    
    // 添加移动端触摸事件支持
    addMobileTouchSupport();

    // 初始化电池状态监测（WebSocket 优先，HTTP 轮询兜底）
    initBatteryMonitor();
});

// 添加移动端触摸事件支持函数
function addMobileTouchSupport() {
    // 为所有按钮添加触摸事件支持
    const buttons = document.querySelectorAll('button');
    
    buttons.forEach(button => {
        // 添加触摸开始事件 - 只用于视觉反馈
        button.addEventListener('touchstart', function(e) {
            this.style.transform = 'scale(0.95)'; // 触摸反馈
            this.style.transition = 'transform 0.1s';
        }, { passive: true });
        
        // 添加触摸结束事件 - 只用于视觉反馈
        button.addEventListener('touchend', function(e) {
            this.style.transform = 'scale(1)';
        }, { passive: true });
        
        // 添加触摸取消事件
        button.addEventListener('touchcancel', function(e) {
            this.style.transform = 'scale(1)';
        });
        
        // 不添加额外的click事件监听器，让原有的onclick属性正常工作
    });
    
    // 为选择框添加触摸优化
    const select = document.getElementById('ssh-target');
    if (select) {
        select.addEventListener('touchstart', function(e) {
            // 确保选择框在移动端有足够的触摸区域
            this.style.fontSize = '16px'; // 防止iOS缩放
        });
    }
}

// ==================== 电池状态 WebSocket & HTTP 监测 ====================

// 云端 WebSocket 地址（用于前端实时显示，可根据需要调整路径）
// 对应后端 HTTP 基础地址 http://8.159.132.117:8888/ 的 WebSocket 形式
const BATTERY_WS_URL = "ws://8.159.132.117:8888/";
let batteryWS = null;
let batteryWSRetry = 0;

function updateBatteryUI(data) {
    const packSpan = document.getElementById('batt-pack-v');
    const curModeSpan = document.getElementById('batt-current-mode');
    const curSpan = document.getElementById('batt-current');
    const socSpan = document.getElementById('batt-soc');
    const tmaxSpan = document.getElementById('batt-tmax');
    const rawDiv = document.getElementById('batt-last-raw');

    if (!packSpan) return;  // 页面上没有电池卡片时直接返回

    packSpan.textContent = (data.pack_voltage ?? "--");
    curModeSpan.textContent = (data.current_mode ?? (data.current >= 0 ? "充电" : "放电"));
    curSpan.textContent = (data.current != null ? Math.abs(data.current).toFixed(2) : "--");
    socSpan.textContent = (data.soc ?? "--");
    tmaxSpan.textContent = (data.tmax ?? "--");

    if (rawDiv) {
        if (data.raw) {
            rawDiv.textContent = "最近数据: " + data.raw;
        } else {
            rawDiv.textContent = "最近数据: " +
                `PACK=${packSpan.textContent}V, 电流=${curModeSpan.textContent} ${curSpan.textContent}A, ` +
                `SOC=${socSpan.textContent}%, Tmax=${tmaxSpan.textContent}℃`;
        }
    }
}

function setBatteryConnStatus(text) {
    const conn = document.getElementById('battery-conn');
    if (conn) conn.textContent = text;
}

function connectBatteryWS() {
    if (!("WebSocket" in window)) {
        setBatteryConnStatus("浏览器不支持 WebSocket，将使用 HTTP 轮询。");
        startBatteryHttpPolling();
        return;
    }

    try {
        batteryWS = new WebSocket(BATTERY_WS_URL);
    } catch (e) {
        setBatteryConnStatus("WebSocket 连接失败，将使用 HTTP 轮询。");
        startBatteryHttpPolling();
        return;
    }

    batteryWS.onopen = function () {
        batteryWSRetry = 0;
        setBatteryConnStatus("已通过 WebSocket 连接云端电池监测。");
    };

    batteryWS.onmessage = function (evt) {
        try {
            const msg = JSON.parse(evt.data);
            // 期望格式: { pack_voltage, current, soc, tmax, current_mode?, raw? }
            updateBatteryUI(msg);
        } catch (e) {
            console.error("解析电池 WebSocket 数据失败:", e);
        }
    };

    batteryWS.onerror = function () {
        console.warn("电池 WebSocket 发生错误。");
    };

    batteryWS.onclose = function () {
        if (batteryWSRetry === 0) {
            setBatteryConnStatus("WebSocket 连接断开，将尝试重连或退回 HTTP 轮询。");
        }
        batteryWSRetry += 1;
        if (batteryWSRetry <= 3) {
            setTimeout(connectBatteryWS, 2000 * batteryWSRetry);
        } else {
            setBatteryConnStatus("WebSocket 多次重连失败，改用 HTTP 轮询。");
            startBatteryHttpPolling();
        }
    };
}

let batteryHttpTimer = null;

function startBatteryHttpPolling() {
    if (batteryHttpTimer) return;
    setBatteryConnStatus("通过 HTTP 轮询获取电池状态...");

    function fetchOnce() {
        fetch("/battery/status/", {
            method: "GET",
            headers: { "X-Requested-With": "XMLHttpRequest" }
        })
            .then(res => res.json())
            .then(data => {
                if (data.status === "ok" && data.data) {
                    updateBatteryUI(data.data);
                }
            })
            .catch(err => {
                console.warn("获取电池状态失败:", err);
            });
    }

    fetchOnce();
    batteryHttpTimer = setInterval(fetchOnce, 5000);  // 5s 一次
}

function initBatteryMonitor() {
    // 页面上有电池卡片时才初始化
    if (!document.getElementById('battery-card')) return;
    connectBatteryWS();
}

function runHuishou() {
    if (!confirm('确定要挥手吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在挥手...');
    makeRequest('/run_huishou/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runHeying() {
    if (!confirm('确定要合影吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在合影...');
    makeRequest('/run_heying/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}


function runJiayou() {
    if (!confirm('确定要加油吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在加油...');
    makeRequest('/run_jiayou/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runYongbao() {
    if (!confirm('确定要拥抱吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在拥抱...');
    makeRequest('/run_yongbao/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runKissTest() {
    // 获取选中的终端
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('kiss-e1009');
    const e1010Checkbox = document.getElementById('kiss-e1010');
    const e_1011Checkbox = document.getElementById('kiss-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) {
        selectedTargets.push('e1009');
    }
    if (e1010Checkbox && e1010Checkbox.checked) {
        selectedTargets.push('e1010');
    }
    if (e_1011Checkbox && e_1011Checkbox.checked) {
        selectedTargets.push('e-1011');
    }
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要向 ${targetNames} 执行Kiss Test吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在向 ${targetNames} 执行Kiss Test...`);
    
    // 直接使用fetch，不使用makeRequest（因为不需要ssh_target参数）
    fetch('/run_kiss_test/', {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runDanceGroup() {
    // 获取选中的终端
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('dance-e1009');
    const e1010Checkbox = document.getElementById('dance-e1010');
    const e_1011Checkbox = document.getElementById('dance-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) {
        selectedTargets.push('e1009');
    }
    if (e1010Checkbox && e1010Checkbox.checked) {
        selectedTargets.push('e1010');
    }
    if (e_1011Checkbox && e_1011Checkbox.checked) {
        selectedTargets.push('e-1011');
    }
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要向 ${targetNames} 执行Dance Group吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在向 ${targetNames} 执行Dance Group...`);
    
    // 直接使用fetch，不使用makeRequest（因为不需要ssh_target参数）
    fetch('/run_dance_group/', {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runPdGroup() {
    // 获取选中的终端
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('pd-e1009');
    const e1010Checkbox = document.getElementById('pd-e1010');
    const e_1011Checkbox = document.getElementById('pd-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) {
        selectedTargets.push('e1009');
    }
    if (e1010Checkbox && e1010Checkbox.checked) {
        selectedTargets.push('e1010');
    }
    if (e_1011Checkbox && e_1011Checkbox.checked) {
        selectedTargets.push('e-1011');
    }
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要向 ${targetNames} 执行PD Group吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在向 ${targetNames} 执行PD Group...`);
    
    // 直接使用fetch，不使用makeRequest（因为不需要ssh_target参数）
    fetch('/run_pd_group/', {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runStopGroup() {
    // 获取选中的终端
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('stop-e1009');
    const e1010Checkbox = document.getElementById('stop-e1010');
    const e_1011Checkbox = document.getElementById('stop-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) {
        selectedTargets.push('e1009');
    }
    if (e1010Checkbox && e1010Checkbox.checked) {
        selectedTargets.push('e1010');
    }
    if (e_1011Checkbox && e_1011Checkbox.checked) {
        selectedTargets.push('e-1011');
    }
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要向 ${targetNames} 执行Stop Group吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在向 ${targetNames} 执行Stop Group...`);
    
    // 直接使用fetch，不使用makeRequest（因为不需要ssh_target参数）
    fetch('/run_stop_group/', {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function testConnectivity() {
    // 获取选中的终端
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('connectivity-e1009');
    const e1010Checkbox = document.getElementById('connectivity-e1010');
    const e_1011Checkbox = document.getElementById('connectivity-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) {
        selectedTargets.push('e1009');
    }
    if (e1010Checkbox && e1010Checkbox.checked) {
        selectedTargets.push('e1010');
    }
    if (e_1011Checkbox && e_1011Checkbox.checked) {
        selectedTargets.push('e-1011');
    }
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要测试 ${targetNames} 的连通性吗？`)) {
        return;
    }
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在测试 ${targetNames} 的连通性...`);
    
    // 直接使用fetch，不使用makeRequest（因为不需要ssh_target参数）
    fetch('/test_connectivity/', {
        method: "POST",
        headers: { 
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function multiReboot() {
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('reboot-e1009');
    const e1010Checkbox = document.getElementById('reboot-e1010');
    const e_1011Checkbox = document.getElementById('reboot-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) selectedTargets.push('e1009');
    if (e1010Checkbox && e1010Checkbox.checked) selectedTargets.push('e1010');
    if (e_1011Checkbox && e_1011Checkbox.checked) selectedTargets.push('e-1011');
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要重启 ${targetNames} 吗？`)) return;
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在重启 ${targetNames}...`);
    
    fetch('/multi_reboot/', {
        method: "POST",
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `<h4>执行成功:</h4><pre>${data.stdout}</pre>${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}`, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function multiPoweroff() {
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('poweroff-e1009');
    const e1010Checkbox = document.getElementById('poweroff-e1010');
    const e_1011Checkbox = document.getElementById('poweroff-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) selectedTargets.push('e1009');
    if (e1010Checkbox && e1010Checkbox.checked) selectedTargets.push('e1010');
    if (e_1011Checkbox && e_1011Checkbox.checked) selectedTargets.push('e-1011');
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要关闭 ${targetNames} 吗？`)) return;
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在关闭 ${targetNames}...`);
    
    fetch('/multi_poweroff/', {
        method: "POST",
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `<h4>执行成功:</h4><pre>${data.stdout}</pre>${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}`, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function multiStartAll() {
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('startall-e1009');
    const e1010Checkbox = document.getElementById('startall-e1010');
    const e_1011Checkbox = document.getElementById('startall-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) selectedTargets.push('e1009');
    if (e1010Checkbox && e1010Checkbox.checked) selectedTargets.push('e1010');
    if (e_1011Checkbox && e_1011Checkbox.checked) selectedTargets.push('e-1011');
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要在 ${targetNames} 启动所有程序吗？`)) return;
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在在 ${targetNames} 启动所有程序...`);
    
    fetch('/multi_start_all/', {
        method: "POST",
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `<h4>执行成功:</h4><pre>${data.stdout}</pre>${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}`, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function multiKillTerminals() {
    const selectedTargets = [];
    const e1009Checkbox = document.getElementById('killterminals-e1009');
    const e1010Checkbox = document.getElementById('killterminals-e1010');
    const e_1011Checkbox = document.getElementById('killterminals-e-1011');
    
    if (e1009Checkbox && e1009Checkbox.checked) selectedTargets.push('e1009');
    if (e1010Checkbox && e1010Checkbox.checked) selectedTargets.push('e1010');
    if (e_1011Checkbox && e_1011Checkbox.checked) selectedTargets.push('e-1011');
    
    if (selectedTargets.length === 0) {
        alert('请至少选择一个目标终端！');
        return;
    }
    
    const targetNames = selectedTargets.map(t => t.toUpperCase()).join(' 和 ');
    if (!confirm(`确定要关闭 ${targetNames} 的所有界面吗？`)) return;
    
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, `正在关闭 ${targetNames} 的所有界面...`);
    
    fetch('/multi_kill_terminals/', {
        method: "POST",
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
        body: JSON.stringify({ targets: selectedTargets })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `<h4>执行成功:</h4><pre>${data.stdout}</pre>${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}`, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace1() {
    if (!confirm('确定要执行face1吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face1...');
    makeRequest('/run_face1/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace2() {
    if (!confirm('确定要执行face2吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face2...');
    makeRequest('/run_face2/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace3() {
    if (!confirm('确定要执行face3吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face3...');
    makeRequest('/run_face3/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace4() {
    if (!confirm('确定要执行face4吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face4...');
    makeRequest('/run_face4/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace5() {
    if (!confirm('确定要执行face5吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face5...');
    makeRequest('/run_face5/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace6() {
    if (!confirm('确定要执行face6吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face6...');
    makeRequest('/run_face6/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace7() {
    if (!confirm('确定要执行face7吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face7...');
    makeRequest('/run_face7/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace8() {
    if (!confirm('确定要执行face8吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face8...');
    makeRequest('/run_face8/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace9() {
    if (!confirm('确定要执行face9吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face9...');
    makeRequest('/run_face9/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

function runFace10() {
    if (!confirm('确定要执行face10吗？')) {
        return;
    }
    const resultDiv = document.getElementById('result');
    showResult(resultDiv, '正在执行face10...');
    makeRequest('/run_face10/', {})
        .then(data => {
            if (data.status === 'ok') {
                showResult(resultDiv, `
                    <h4>执行成功:</h4>
                    <pre>${data.stdout}</pre>
                    ${data.stderr ? `<h4>错误输出:</h4><pre>${data.stderr}</pre>` : ''}
                `, true);
            } else {
                showResult(resultDiv, `<h4>执行失败:</h4><pre>${data.message}</pre>`, true);
            }
        })
        .catch(error => {
            showResult(resultDiv, `<h4>请求失败:</h4><pre>${error.message}</pre>`, true);
        });
}

// 移动端弹窗函数
function showMobileAlert(message) {
    console.log('显示移动端警告:', message);
    
    // 尝试使用原生alert
    try {
        alert(message);
    } catch (e) {
        console.error('原生alert失败:', e);
        // 备用方案：在页面上显示消息
        const resultDiv = document.getElementById('result');
        if (resultDiv) {
            showResult(resultDiv, `<div style="color: red; font-weight: bold;">${message}</div>`, true);
        }
    }
}

function showMobileConfirm(message, callback) {
    console.log('显示移动端确认对话框:', message);
    
    // 尝试使用原生confirm
    try {
        const result = confirm(message);
        if (callback) {
            callback(result);
        }
    } catch (e) {
        console.error('原生confirm失败:', e);
        // 备用方案：在页面上显示确认按钮
        showCustomConfirm(message, callback);
    }
}

function showCustomConfirm(message, callback) {
    // 创建自定义确认对话框
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 10000;
        display: flex;
        justify-content: center;
        align-items: center;
    `;
    
    const dialog = document.createElement('div');
    dialog.style.cssText = `
        background: white;
        padding: 20px;
        border-radius: 10px;
        max-width: 80%;
        text-align: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    `;
    
    dialog.innerHTML = `
        <p style="margin: 0 0 20px 0; font-size: 16px;">${message}</p>
        <div style="display: flex; gap: 10px; justify-content: center;">
            <button id="confirm-yes" style="
                background: #4CAF50;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
            ">确定</button>
            <button id="confirm-no" style="
                background: #f44336;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
            ">取消</button>
        </div>
    `;
    
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    // 添加事件监听器
    document.getElementById('confirm-yes').addEventListener('click', function() {
        document.body.removeChild(overlay);
        if (callback) callback(true);
    });
    
    document.getElementById('confirm-no').addEventListener('click', function() {
        document.body.removeChild(overlay);
        if (callback) callback(false);
    });
    
    // 点击遮罩层关闭
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            document.body.removeChild(overlay);
            if (callback) callback(false);
        }
    });
}