from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
import threading
import paramiko
import json
import os
import re
from functools import wraps

# SSH 终端配置
SSH_CONFIG = {
    "e1010": {
        "host": "160.202.240.232",
        "port": 9018,
        "user": "pc",
        "pass": "123"   
    },
    "e1009": {
        "host": "160.202.240.232",
        "port": 9011,
        "user": "pc",
        "pass": "123"   
    },
    "e-1011": {
        "host": "160.202.240.232",
        "port": 9017,
        "user": "pc",
        "pass": "123"   
    }
}

def ssh_connect(target="e1009"):
    """创建SSH连接"""
    cfg = SSH_CONFIG.get(target)
    if not cfg:
        raise ValueError("未找到对应 SSH 配置")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=cfg["host"], port=cfg["port"], username=cfg["user"], password=cfg["pass"])
    return ssh

def ssh_operation(func):
    """装饰器：处理SSH操作的通用逻辑"""
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        if request.method != "POST":
            return JsonResponse({"status": "invalid request"})
        
        try:
            data = json.loads(request.body)
            target = data.get("ssh_target", "e1009")
            
            # 调用原函数，传入SSH连接和解析后的数据
            result = func(request, data, target, *args, **kwargs)
            return result
        except json.JSONDecodeError:
            return JsonResponse({"status": "error", "message": "无效的JSON数据"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return wrapper


# ===== 电池监测相关：读取 battery.py 生成的日志，解析四个关键参数 =====

BATTERY_LOG_PATH = "/home/pc/battery_test/battrey.txt"


@require_http_methods(["GET"])
@login_required
def get_battery_status(request):
    """
    从 battery.py 生成的日志中读取最新一行，解析并返回：
    - PACK 总电压
    - 电池电流（含充电/放电状态）
    - SOC
    - 最高温度
    """
    try:
        if not os.path.exists(BATTERY_LOG_PATH):
            return JsonResponse({"status": "error", "message": "未找到电池日志文件"})

        last_line = ""
        with open(BATTERY_LOG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    last_line = line

        if not last_line:
            return JsonResponse({"status": "error", "message": "电池日志为空"})

        # 解析形如：
        # [2025-12-18 13:55:11] PACK 总电压:  52.56 V | 电池电流: 充电   3.31 A | SOC:  68 % | 最高温度:  26.6 ℃ | 状态: 正常
        m = re.search(
            r"PACK 总电压:\s*([0-9.]+)\s*V\s*\|\s*"
            r"电池电流:\s*(充电|放电|静止)\s*([0-9.]+)\s*A\s*\|\s*"
            r"SOC:\s*([0-9]+)\s*%\s*\|\s*"
            r"最高温度:\s*([0-9.]+)\s*℃",
            last_line,
        )
        if not m:
            return JsonResponse(
                {"status": "error", "message": "解析电池日志失败", "raw": last_line}
            )

        pack_v_str, mode, current_str, soc_str, tmax_str = m.groups()
        data = {
            "pack_voltage": float(pack_v_str),
            "current_mode": mode,  # 充电/放电/静止
            "current": float(current_str),
            "soc": int(soc_str),
            "tmax": float(tmax_str),
            "raw": last_line,
        }

        return JsonResponse({"status": "ok", "data": data})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_dianzan(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'dianzan'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_bixin(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'bixin'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_woshou(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'woshou'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_xiexie(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'xiexie'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_paizhao(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'paizhao'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_jujue(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'jujue'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_maimeng(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'maimeng'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_buyao(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'left_direction'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_huishou(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'huishou'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_heying(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'heying'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_jiayou(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'jiayou'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
@ssh_operation
def run_yongbao(request, data, target):
    ssh = ssh_connect(target)
    stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /action std_msgs/String \"data: 'right_direction'\" --once")
    out = stdout.read().decode()
    err = stderr.read().decode()
    ssh.close()

    return JsonResponse({"status": "ok", "stdout": out, "stderr": err})


@require_http_methods(["POST"])
@login_required
def run_kiss_test(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    # 从前端获取选中的目标列表
    targets = data.get("targets", [])
    
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    # 验证目标是否合法
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /kiss_group std_msgs/Float32 \"data: 1.0\" --once")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    # 创建并启动线程，实现并发执行
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    # 合并结果
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def run_dance_group(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    # 从前端获取选中的目标列表
    targets = data.get("targets", [])
    
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    # 验证目标是否合法
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /dance_group std_msgs/Float32 \"data: 1.0\" --once")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    # 创建并启动线程，实现并发执行
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    # 合并结果
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def run_pd_group(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    # 从前端获取选中的目标列表
    targets = data.get("targets", [])
    
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    # 验证目标是否合法
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /pd_group std_msgs/Float32 \"data: 1.0\" --once")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    # 创建并启动线程，实现并发执行
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    # 合并结果
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def test_connectivity(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    # 从前端获取选中的目标列表
    targets = data.get("targets", [])
    
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    # 验证目标是否合法
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("ip a")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    # 创建并启动线程，实现并发执行
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    # 合并结果
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def multi_reboot(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    targets = data.get("targets", [])
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;sudo reboot")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def multi_poweroff(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    targets = data.get("targets", [])
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;sudo poweroff")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def multi_start_all(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    targets = data.get("targets", [])
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0; ~/roslaunch_autostart.sh")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def multi_kill_terminals(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    targets = data.get("targets", [])
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0; pkill gnome-terminal")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })


@require_http_methods(["POST"])
@login_required
def run_stop_group(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"status": "error", "message": "无效的JSON数据"})
    
    # 从前端获取选中的目标列表
    targets = data.get("targets", [])
    
    if not targets:
        return JsonResponse({"status": "error", "message": "未选择任何目标终端"})
    
    # 验证目标是否合法
    valid_targets = ["e1009", "e1010", "e-1011"]
    targets = [t for t in targets if t in valid_targets]
    
    if not targets:
        return JsonResponse({"status": "error", "message": "选择的目标终端无效"})
    
    results = {}
    
    def execute_command(target_name):
        try:
            ssh = ssh_connect(target_name)
            stdin, stdout, stderr = ssh.exec_command("export DISPLAY=:0;  source /opt/ros/noetic/setup.bash;rostopic pub /stop_group std_msgs/Float32 \"data: 1.0\" --once")
            out = stdout.read().decode()
            err = stderr.read().decode()
            ssh.close()
            results[target_name] = {"stdout": out, "stderr": err, "success": True}
        except Exception as e:
            results[target_name] = {"stdout": "", "stderr": str(e), "success": False}
    
    # 创建并启动线程，实现并发执行
    threads = []
    for t in targets:
        thread = threading.Thread(target=execute_command, args=(t,))
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    # 合并结果
    combined_stdout = [f"[{t.upper()}] {results[t]['stdout']}" for t in targets if t in results]
    combined_stderr = [f"[{t.upper()}] {results[t]['stderr']}" for t in targets if t in results and results[t]['stderr']]
    
    return JsonResponse({
        "status": "ok", 
        "stdout": "\n".join(combined_stdout), 
        "stderr": "\n".join(combined_stderr)
    })
